package com.ameya.pojo;

public class Greeting {
	private String message;
	public Greeting() { 
		System.out.println("+++ Default Invoked +++");
	}
	public Greeting(String message) {
		this.message = message;
		System.out.println("+++ Parameterized invoked +++");
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "Greeting [message=" + message +"  "+hashCode() +" ]";
	}
	public static Greeting create() {
		Greeting g=new Greeting();
		//if(some condition then set following value)
		g.setMessage("Some message");
		//else set some other value
		return g;
	}
	
	public void init() {
		System.out.println("+++ Bean is being Initialized +++");
	}
	
	public void destroy() {
		System.out.println("+++ Bean is about to be destroyed +++");
	}
}
