package com.ameya.pojo;

public class Employee {
	private String firstName;
	private String lastName;
	private Project project;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String firstName, String lastName, Project project) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.project = project;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}
	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + 
	lastName +", hashcode="+hashCode() +", project=" + getProject() + "]";
	}
}
