package com.ameya.pojo;

public class Project {
	private String projectName;
	private Integer duration;
	public Project() {}
	public Project(String projectName, Integer duration) {
		this.projectName = projectName;
		this.duration = duration;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "Project [projectName=" + projectName + ","
				+ " duration=" + duration + ", hashcode="+hashCode()+"]";
	}
}
