package com.ameya.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ameya.pojo.Greeting;

public class TestDI {

	public static void main(String[] args) {
		ApplicationContext ctx=new 
				ClassPathXmlApplicationContext("beans.xml");
		Greeting gr1=(Greeting)ctx.getBean("gr1");
		System.out.println(gr1);
		Greeting gr2=(Greeting)ctx.getBean("gr1");
		System.out.println(gr2);
		Greeting gr3=(Greeting)ctx.getBean("gr1");
		System.out.println(gr3);
		Greeting gr4=(Greeting)ctx.getBean("gr1");
		System.out.println(gr4);
	}
}
