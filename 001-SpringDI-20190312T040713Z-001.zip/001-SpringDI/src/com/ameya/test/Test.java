package com.ameya.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ameya.pojo.Employee;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		
		Employee e1=(Employee)ctx.getBean("emp1");
		Employee e2=(Employee)ctx.getBean("emp1");
		System.out.println(e1);
		System.out.println(e2);
	}
}
