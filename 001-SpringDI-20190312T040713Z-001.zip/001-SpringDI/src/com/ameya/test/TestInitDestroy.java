package com.ameya.test;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ameya.pojo.Greeting;

public class TestInitDestroy {

	public static void main(String[] args) {
		AbstractApplicationContext ctx=new 
				ClassPathXmlApplicationContext("init-destroy.xml");
		
		Greeting gr1=(Greeting)ctx.getBean("gr1");
		Greeting gr2=(Greeting)ctx.getBean("gr2");
		System.out.println(gr1);
		System.out.println(gr2);
		
		ctx.registerShutdownHook();
		ctx.close();
	}

}
