This demo is of microservices using spring boot

We code in the microservice AccountService 
and deploy them using Eureka/Zuul/Zipkin

It consists of 4 services

AccountRestService Project -->Your Business microservice (Note the dependencies for zipkin and sleuth also note the sampler method and sleuth properties in yml file)

EurekaDiscoveryServer -->Registry your services are registerd with Eureka server

ZuulGatewayServer -->Creates the proxy (ZUUL proxy) for your services(Note the dependencies for zipkin and sleuth also note the sampler method and sleuth properties in yml file)

zipkin-service -->https://github.com/openzipkin/zipkin download zipkin server here

run java -jar zipkinxxx.jar
invoke http://localhost:9411/zipkin

--- Windows
If the port 9411 is already used then using Resource Monitor -> networking->listening ports identify the process listening on that port and kill it then start the zipkin server

--- Linux
If the port 9411 is already used by other service
ubuntu1804javaspringboot@ubuntu:~$ sudo lsof -t -i:9411
this command will return a number say 3630 (just example actual output will be different) this is the pid
ubuntu1804javaspringboot@ubuntu:~$ sudo kill 3630

OR

java -jar ./zipkin/zipkin-server-2.12.1-exec.jar --QUERY_PORT=9422
This will run zipkin on different port in this case 9422
Mention this port in the .properties/.yml files for AccountRestService and ZuulGatewayServer
spring.application.zipkin.base-url: http://localhost:9422/

NOTE : account-service xx% means the percentage of the total trace time that span has taken

Writedown the required classes and interfaces refering to the sample project

Note the varoius annotations @SpringbootApplication @RestController etc


While running Run in the following order (port nos. and all configurations in application.yml files)
	discovery-service (runs on port 8761)
	gateway-service (runs on port 8765)
	account-service (runs on port 2222) 
	

The services should be invoked using port to which gateway-service listens (8765 in this case)
The url patterns are mentioned in application.yml of gateway-service project.

The dicovery-service can be invoked using the port to which it listens(8761 in this case)


Sample URLS :

http://localhost:8765/account/accounts
http://localhost:8765/account/accounts/222222