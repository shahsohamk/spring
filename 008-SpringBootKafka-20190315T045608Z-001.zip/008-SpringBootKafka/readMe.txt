Create anew Spring starter Project 008-SpringBootKafka
Add the dependencies for spring kafka, web
Make the port groupid bootStrapServers entries as in yml file
Create the kafka Receiver class and expose it as Component as in KafkaReceiver.java
Note the @KafkaListener
Create the Kafka Sender class inject the KafkaTemplate and invoke the send method as in KafkaSender.java

Create the DemoRestService and provide the rest endpoint as in DemoRestService.java

Start the zookeeper service -->Kafka internally uses this
ubuntu1804javaspringboot@ubuntu:~/kafka/kafka_2.12-2.1.1/bin$ ./zookeeper-server-start.sh ../config/zookeeper.properties
Start the Kafka Service 
ubuntu1804javaspringboot@ubuntu:~/kafka/kafka_2.12-2.1.1/bin$ ./kafka-server-start.sh ../config/server.properties

Run the application as Spring boot app

Through Postman clinet put up the post request 

URL : localhost:9001/kafka/syncOrdersTopic 

body : { "message" : "Initiate Order Sync"}

URL : localhost:9001/kafka/startPaymentTopic 

body : { "message" : "Initiate Payment"}

Observe the Console
