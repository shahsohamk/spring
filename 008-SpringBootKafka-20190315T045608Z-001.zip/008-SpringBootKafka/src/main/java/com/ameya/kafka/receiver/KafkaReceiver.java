package com.ameya.kafka.receiver;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class KafkaReceiver {
	//@KafkaListener(topics = "syncOrdersTopic",groupId = "ecommerce")-->Only the cosumers belonging to this group
    @KafkaListener(topics = "syncOrdersTopic")
    public void receiveTopic1(ConsumerRecord<?, ?> consumerRecord) {
        System.out.println("Receiver on syncOrdersTopic : "+consumerRecord.toString());
		System.out.println("++++ Invoked Service for Synchronizing Orders ++++");
    }

    @KafkaListener(topics = "startPaymentTopic")
    public void receiveTopic2(ConsumerRecord<?, ?> consumerRecord) {
        System.out.println("Receiver on startPaymentTopic : "+consumerRecord.toString());
		System.out.println("++++ Invoked Service for Payment Integration ++++");
    }

}
