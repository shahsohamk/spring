This Project demonstrates Spring Collections List/Set/Map

Create classes Customer/Person in com.ameya.pojos
Create beans.xml with <list>...</list> , <set>...</set> , <map>...</map> , <props>...</props>

<map> will need <entry> with key/value pairs
<props> will need <prop> within it

Create TestCollections in com.ameya.test 