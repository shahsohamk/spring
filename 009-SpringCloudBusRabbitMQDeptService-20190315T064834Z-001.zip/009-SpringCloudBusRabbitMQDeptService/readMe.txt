Create a spring starter project 009-SpringCloudBusRabbitMQDeptservice

add dependencies for web, actuator, spring-cloud-starter-config, spring-cloud-starter-bus-amqp as in pom.xml

add the entries in application.properties and bootstrap.properties

Create the Controller Class note the annotations

add the files department-service.properties and employee-service.properties with key/value pair to git repo config-server-repo
ubuntu1804javaspringboot@ubuntu:~/config-server-repo$ git add .
ubuntu1804javaspringboot@ubuntu:~/config-server-repo$ git commit -m "added two property files"

Start the SpringCloudConfigServer
Invoke from terminal window : 
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:9088/department-service/default/
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:9088/employee-service/default/

Start the Department service and employee service
Invoke from the terminal window :
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:8082/service
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:8082/service

Modify the value from the department-service.properties and employee-service.properties file
ubuntu1804javaspringboot@ubuntu:~/config-server-repo$ git add .
ubuntu1804javaspringboot@ubuntu:~/config-server-repo$ git commit -m "modified the property files"

Invoke from terminal window : 
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:9088/department-service/default/
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:9088/employee-service/default/

Refresh all the services

ubuntu1804javaspringboot@ubuntu:~$ curl -X POST http://localhost:8081/actuator/bus-refresh

Now again Invoke from the terminal window :
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:8082/service
ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:8082/service
